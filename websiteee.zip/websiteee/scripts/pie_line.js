var dom = document.getElementById('pieline');
    var myChart = echarts.init(dom, 'dark', {
      renderer: 'canvas',
      useDirtyRect: false
    });
    var app = {};
    
    var option;

    setTimeout(function () {
  option = {
    legend: {},
    tooltip: {
      trigger: 'axis',
      showContent: false
    },
    dataset: {
      source: [
        ['product', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
        ['Anti-social behaviour', 73,79,	53	,25,	46	,41,	35	,49	,56	,61	,74	,63],
        ['Bicycle theft', 37	,31	,29,	8,	14,	38,	42,	64,	55,	63,	45,	14],
        ['Burglary', 30,	14	,22,	27,	16,	9	,14,	12,	18,	12	,5,	9],
        ['Criminal damage and arson', 19,	22	,16	,6	,13	,10,	21,	22,	28,	28	,10	,19],
        ['Drugs', 70,	34,	36,	20	,29,	45,	59,	50,	57,	46,	63,	50],
        ['Other crime',14	,10	,11,	11,	6	,6,	6	,7,	7,	10,	5,	9],
        ['Other theft', 181,	214	,155,	16,	10,	20,	39,	50,	69,	68,	32,	40],
        ['Possession of weapons', 5,	2,	8,	5,	2,	7,	6,	4,	4,	1,	2,	5],
        ['Public order', 31,	31,	30,	11,	9,	22,	26,	28,	31,	19,	29,	14],
        ['Robbery', 12,	7	,5,	0,	5,	5	,10,	9,	5,	6	,12,	9],
        ['Shoplifting', 63,	73,	62,	44,	18,	47,	61,	68,	53,	60,	59,	46],
        ['Theft from the person', 65,	86,	48,	15,	11,	13,	44,	26,	35,	43,	49,	27],
        ['Vehicle crime', 26,	20,	17,	2,	8,	5	,20,	10,	16,	10,	9,	10],
        ['Violence and sexual offences', 103,	86,	72,	22,	20,	20,	41,	54,	62,	63,	46,	53]
      ]
    },
    xAxis: { type: 'category' },
    yAxis: { gridIndex: 0 },
    grid: { top: '55%' },
    series: [
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'line',
        smooth: true,
        seriesLayoutBy: 'row',
        emphasis: { focus: 'series' }
      },
      {
        type: 'pie',
        id: 'pie',
        radius: '30%',
        center: ['50%', '25%'],
        emphasis: {
          focus: 'self'
        },
        label: {
          formatter: '{b}: {@2012} ({d}%)'
        },
        encode: {
          itemName: 'product',
          value: 'Jan',
          tooltip: 'Jan'
        }
      }
    ]
  };
  myChart.on('updateAxisPointer', function (event) {
    const xAxisInfo = event.axesInfo[0];
    if (xAxisInfo) {
      const dimension = xAxisInfo.value + 1;
      myChart.setOption({
        series: {
          id: 'pie',
          label: {
            formatter: '{b}: {@[' + dimension + ']} ({d}%)'
          },
          encode: {
            value: dimension,
            tooltip: dimension
          }
        }
      });
    }
  });
  myChart.setOption(option);
});

    if (option && typeof option === 'object') {
      myChart.setOption(option);
    }

    window.addEventListener('resize', myChart.resize);
